import { Outlet, Link } from "react-router-dom";
import { useState } from "react";

const Layout = () => {
  
 
  
    return (
      <div>
        <nav>
          <ul style={{ display: "flex", justifyContent: "space-evenly" }}>
            <li>
              <Link to="/">Signup</Link>
            </li>
            <li>
              <Link to="/Login" >Login</Link>
            </li>
          </ul>
        </nav>
        <Outlet />
      </div>
    );
  } 
    
 

export default Layout;
