export function getimageurl(person){
    return{
        
    }
}